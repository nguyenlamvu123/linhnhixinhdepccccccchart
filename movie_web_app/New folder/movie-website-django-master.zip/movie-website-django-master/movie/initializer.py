from movie.search_cache import LRU
from movie.search_index import Index

search_cache = LRU()
search_index = Index()
